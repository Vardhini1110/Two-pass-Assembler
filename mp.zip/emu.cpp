// ------------------------------------------------------------------
// Declaration of Authorship :
// identifier : ALLAM VISHNU VARDHINI
// Roll No: 2301AI35
// --------------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>

using namespace std;

// Function prototypes
string toHexString(int value);
void runExecutionCycle(int instructionCount);
void showOpcodeInfo();
void resetAllRegisters();
void displayMemoryStateBeforeExecution(int instructionCount);
void displayMemoryStateAfterExecution(int instructionCount);
void logMemoryReads();
void logMemoryWrites();

// Global variables (memory, registers)
int memorySpace[20000005];
int programCounter = 0, stackPointer = 0, regA = 0, regB = 0;
vector<int> instructionsList;

struct MemoryTransaction
{
    int address;
    int oldValue;
    int newValue;
};

vector<MemoryTransaction> memoryReadLogs;
vector<MemoryTransaction> memoryWriteLogs;

// Convert an integer to a hex string with leading zeros
string toHexString(int value)
{
    stringstream ss;
    ss << setw(8) << setfill('0') << hex << value;
    return ss.str();
}

// Helper function for reading from memory
int readFromMemory(int address)
{
    if (address < 0 || address >= sizeof(memorySpace) / sizeof(memorySpace[0]))
    {
        cout << "Error: Attempted to read from invalid memory address.\n";
        exit(1);
    }
    return memorySpace[address];
}

// Helper function for writing to memory
void writeToMemory(int address, int value)
{
    if (address < 0 || address >= sizeof(memorySpace) / sizeof(memorySpace[0]))
    {
        cout << "Error: Attempted to write to invalid memory address.\n";
        exit(1);
    }
    memorySpace[address] = value;
}

// Function to execute the program step by step
void runExecutionCycle(int instructionCount)
{
    int instructionIndex = 0;
    bool isHalted = false;
    int cycleCount = 0;

    while (instructionIndex < instructionCount && !isHalted)
    {
        int currentInstruction = instructionsList[instructionIndex];
        int opcode = currentInstruction & 0xFF;            // Lower 8 bits for opcode
        int offset = (currentInstruction >> 8) & 0x7FFFFF; // Upper 23 bits for offset

        // Handle signed offset
        if (currentInstruction & (1 << 31))
        {
            offset -= (1 << 23);
        }

        int prevValue = -1;

        // Execute the corresponding operation based on the opcode
        switch (opcode)
        {
        case 0: // Load constant
            regB = regA;
            regA = offset;
            break;
        case 1: // Add constant
            regA += offset;
            break;
        case 2: // Load from stack
            regB = regA;
            regA = readFromMemory(stackPointer + offset);
            memoryReadLogs.push_back({stackPointer + offset, regA, regA});
            break;
        case 3: // Store to stack
            prevValue = readFromMemory(stackPointer + offset);
            writeToMemory(stackPointer + offset, regA);
            regA = regB;
            memoryWriteLogs.push_back({stackPointer + offset, prevValue, regA});
            break;
        case 4: // Load from non-local address
            regB = regA;
            regA = readFromMemory(regA + offset);
            memoryReadLogs.push_back({regA + offset, regA, regA});
            break;
        case 5: // Store to non-local address
            prevValue = readFromMemory(regA + offset);
            writeToMemory(regA + offset, regB);
            memoryWriteLogs.push_back({regA + offset, prevValue, regB});
            break;
        case 6: // Add registers
            regA = regB + regA;
            break;
        case 7: // Subtract registers
            regA = regB - regA;
            break;
        case 8: // Shift left
            regA = regB << regA;
            break;
        case 9: // Shift right
            regA = regB >> regA;
            break;
        case 10: // Adjust stack pointer
            stackPointer += offset;
            break;
        case 11: // Move register A to stack pointer
            stackPointer = regA;
            regA = regB;
            break;
        case 12: // Move stack pointer to register A
            regB = regA;
            regA = stackPointer;
            break;
        case 13: // Call function
            regB = regA;
            regA = programCounter;
            programCounter += offset;
            break;
        case 14: // Return from function
            programCounter = regA;
            regA = regB;
            break;
        case 15: // Branch if zero
            if (regA == 0)
                programCounter += offset;
            break;
        case 16: // Branch if less than zero
            if (regA < 0)
                programCounter += offset;
            break;
        case 17: // Unconditional branch
            programCounter += offset;
            break;
        case 18: // Halt execution
            isHalted = true;
            break;
        default:
            break;
        }

        instructionIndex++;
        cycleCount++;

        // Output register states in hexadecimal format
        cout << "PC=" << toHexString(cycleCount) << " SP=" << toHexString(stackPointer)
             << " A=" << toHexString(regA) << " B=" << toHexString(regB) << endl;

        // Prevent program from running indefinitely
        if (instructionIndex < 0 || cycleCount > (1 << 24))
        {
            cout << "Error: Program encountered an unexpected issue.\n";
            exit(1);
        }

        if (isHalted)
            break;
    }

    cout << "Executed " << cycleCount << " instructions successfully." << endl;
}

// Display available opcodes and their mnemonics
void showOpcodeInfo()
{
    cout << "Opcode    Mnemonic   Operand\n";
    cout << "0         ldc        value\n";
    cout << "1         adc        value\n";
    cout << "2         ldl        value\n";
    cout << "3         stl        value\n";
    cout << "4         ldnl       value\n";
    cout << "5         stnl       value\n";
    cout << "6         add        \n";
    cout << "7         sub        \n";
    cout << "8         shl        \n";
    cout << "9         shr        \n";
    cout << "10        adj        value\n";
    cout << "11        a2sp       \n";
    cout << "12        sp2a       \n";
    cout << "13        call       offset\n";
    cout << "14        return     \n";
    cout << "15        brz        offset\n";
    cout << "16        brlz       offset\n";
    cout << "17        br         offset\n";
    cout << "18        halt       \n";
}

// Reset all registers to initial state
void resetAllRegisters()
{
    regA = regB = programCounter = stackPointer = 0;
}

// Display memory state before execution
void displayMemoryStateBeforeExecution(int instructionCount)
{
    cout << "Memory before execution:\n";
    for (int i = 0; i < instructionCount; i += 4)
    {
        cout << toHexString(i) << " ";
        for (int j = i; j < min(instructionCount, i + 4); ++j)
        {
            cout << toHexString(instructionsList[j]) << " ";
        }
        cout << endl;
    }
}

// Display memory state after execution
void displayMemoryStateAfterExecution(int instructionCount)
{
    cout << "Memory after execution:\n";
    for (int i = 0; i < instructionCount; i += 4)
    {
        cout << toHexString(i) << " ";
        for (int j = i; j < min(instructionCount, i + 4); ++j)
        {
            cout << toHexString(memorySpace[j]) << " ";
        }
        cout << endl;
    }
}

// Log all memory read operations
void logMemoryReads()
{
    for (const auto &read : memoryReadLogs)
    {
        cout << "Read from memory[" << toHexString(read.address) << "] with value "
             << toHexString(read.oldValue) << endl;
    }
}

// Log all memory write operations
void logMemoryWrites()
{
    for (const auto &write : memoryWriteLogs)
    {
        cout << "Wrote to memory[" << toHexString(write.address) << "] value was "
             << toHexString(write.oldValue) << ", now " << toHexString(write.newValue) << endl;
    }
}

// Main function to control execution flow
int main()
{
    string filePath;
    cout << "Enter the path to your binary program file: ";
    cin >> filePath;

    ifstream inputFile(filePath, ios::in | ios::binary);
    unsigned int loadedInstruction;
    int index = 0;

    // Read binary file and store instructions in the vector
    while (inputFile.read(reinterpret_cast<char *>(&loadedInstruction), sizeof(int)))
    {
        instructionsList.push_back(loadedInstruction);
        memorySpace[index++] = loadedInstruction;
    }

    int instructionCount = instructionsList.size();

    while (true)
    {
        cout << "\n--- Menu ---\n";
        cout << "1: Run Program\n";
        cout << "2: Show Available Opcodes\n";
        cout << "3: Reset Registers\n";
        cout << "4: Display Memory Before Execution\n";
        cout << "5: Display Memory After Execution\n";
        cout << "6: Show Memory Reads\n";
        cout << "7: Show Memory Writes\n";
        cout << "Any other option to exit\n";

        int userChoice;
        cout << "Select an option: ";
        cin >> userChoice;

        switch (userChoice)
        {
        case 1:
            runExecutionCycle(instructionCount);
            break;
        case 2:
            showOpcodeInfo();
            break;
        case 3:
            resetAllRegisters();
            break;
        case 4:
            displayMemoryStateBeforeExecution(instructionCount);
            break;
        case 5:
            displayMemoryStateAfterExecution(instructionCount);
            break;
        case 6:
            logMemoryReads();
            break;
        case 7:
            logMemoryWrites();
            break;
        default:
            return 0;
        }
    }
}
