// ------------------------------------------------------------------
// Declaration of Authorship :
// identifier : ALLAM VISHNU VARDHINI
// Roll No: 2301AI35
// --------------------------------------------------------------------
#include <bits/stdc++.h>
#define mp make_pair
#define pb push_back
#define fr first
#define sc second
#define ins insert
#define ii pair<int, int>
#define iii pair<int, pair<int, int>>
#define vi vector<int>
using namespace std;

// Define structure for symbols
struct SymbolEntry
{
    string identifier;
    int memoryAddress;
    bool isInitialized;
    int initialValue;
};

// Define structure for literals
struct LiteralEntry
{
    int value;    // renamed from 'literal' for clarity
    int location; // renamed from 'address' for clarity
};

// Symbol table
vector<SymbolEntry> symbolTable; // Renamed symbol to SymbolEntry and symbolTable to symbolTable

// Literal table
vector<LiteralEntry> literalTable; // Renamed literal to LiteralEntry and literalTable to literalTable

// Utility function to trim leading and trailing white spaces
static inline string &trim(string &s)
{
    s.erase(find_if(s.rbegin(), s.rend(),
                    not1(ptr_fun<int, int>(isspace)))
                .base(),
            s.end());
    s.erase(s.begin(), find_if(s.begin(), s.end(),
                               not1(ptr_fun<int, int>(isspace))));
    return s;
}

// Utility function to check if a string represents a number
bool isNumeric(const std::string &input)
{
    std::string temp = input;
    int index = 0;

    // Handle potential sign
    if (temp.front() == '-' || temp.front() == '+')
    {
        temp = temp.substr(1); // Remove the sign for further checks
    }
    // Handle hexadecimal numbers
    else if (temp.find("0x") == 0)
    {
        temp = temp.substr(2); // Remove "0x" prefix for hexadecimal
    }

    // Check if all characters are digits
    for (auto &ch : temp)
    {
        if (!std::isdigit(ch))
        {
            return false; // If a non-digit is found, return false
        }
    }

    return !temp.empty(); // Ensure the string is not empty
}

// Utility function to convert a string from any base to decimal
int convertToDecimal(string input)
{
    trim(input); // Trim whitespace from input (pass by reference)
    if (input.find("0x") == 0)
    {
        // Hexadecimal (base 16) number
        return stoi(input, nullptr, 16);
    }
    else if (input.find("0") == 0 && input.length() > 1)
    {
        // Octal (base 8) number
        return stoi(input, nullptr, 8);
    }
    else if (input.front() == '-')
    {
        // Negative decimal number
        return -stoi(input.substr(1), nullptr, 10);
    }
    else if (input.front() == '+')
    {
        // Positive decimal number
        return stoi(input.substr(1), nullptr, 10);
    }
    else
    {
        // Default decimal (base 10) number
        return stoi(input, nullptr, 10);
    }
}

// Utility function to check if a symbol exists in the symbol table
bool symbolExists(const string &symbolName)
{
    auto iter = find_if(symbolTable.begin(), symbolTable.end(),
                        [&](const SymbolEntry &sym)
                        { return sym.identifier == symbolName; });
    return iter != symbolTable.end(); // Return true if found, otherwise false
}

// Utility function to convert int to hexadecimal string
string intToHex(int value)
{
    stringstream stream;
    stream << setfill('0') << setw(8) << hex << value;
    return stream.str();
}

// Utility function to check if a label identifier is valid
bool isValidLabel(const string &label)
{
    // Label must start with a letter (uppercase or lowercase)
    if (label.empty() || !isalpha(label[0]))
        return false;

    // Remaining characters must be alphanumeric (letters or digits)
    for (size_t i = 1; i < label.length(); ++i)
    {
        if (!isalnum(label[i]))
            return false;
    }

    return true;
}

// MOT (Mnemonic Operation Table)
std::unordered_map<std::string, std::string> mot = {
    {"ldc", "00"},
    {"adc", "01"},
    {"ldl", "02"},
    {"stl", "03"},
    {"ldnl", "04"},
    {"stnl", "05"},
    {"add", "06"},
    {"sub", "07"},
    {"shl", "08"},
    {"shr", "09"},
    {"adj", "0a"},
    {"a2sp", "0b"},
    {"sp2a", "0c"},
    {"call", "0d"},
    {"return", "0e"},
    {"brz", "0f"},
    {"brlz", "10"},
    {"br", "11"},
    {"HALT", "12"},
    {"data", "00"},
    {"SET", "14"}};
// Function to process instructions and add entries to literal and symbol tables
string addInstructionToTables(string instruction, int *locationPointer, int lineNumber)
{
    int currentLocation = *locationPointer;
    string errorMessages = "";

    // Check for label and variables
    if (instruction.find(':') != string::npos)
    {
        int colonPosition = instruction.find(":", 0);

        if (symbolExists(instruction.substr(0, colonPosition)))
        {
            cout << "ERROR: Duplicate label detected at line " << lineNumber << endl;
            errorMessages += "ERROR: Duplicate label at line " + to_string(lineNumber) + "\n";
        }

        if (!isValidLabel(instruction.substr(0, colonPosition)))
        {
            cout << "WARNING: Invalid label format at line " << lineNumber << endl;
            errorMessages += "WARNING: Incorrect label format at line " + to_string(lineNumber) + "\n";
        }

        // Check for instructions following the label
        if (colonPosition != instruction.length() - 1)
        {
            string remainingInstruction = instruction.substr(colonPosition + 1, instruction.length());
            remainingInstruction = trim(remainingInstruction);
            addInstructionToTables(remainingInstruction, &currentLocation, lineNumber);
            int firstSpace = remainingInstruction.find(" ", 0);
            string operation = remainingInstruction.substr(0, firstSpace);
            string operand = remainingInstruction.substr(firstSpace + 1, remainingInstruction.length());
            operation = trim(operation);
            operand = trim(operand);

            // Handle "SET" operation specifically
            if (operation == "SET")
            {
                symbolTable.push_back({instruction.substr(0, colonPosition), currentLocation, 1, stoi(operand)});
            }
            else
            {
                symbolTable.push_back({instruction.substr(0, colonPosition), currentLocation, 0, -1});
            }
        }
        else
        {
            *locationPointer = *locationPointer - 1;
            symbolTable.push_back({instruction.substr(0, colonPosition), currentLocation, 0, -1});
        }
    }

    // Process literals or constants if no label
    else
    {
        // Assume the second part of the instruction is the operand
        int firstSpace = instruction.find(" ", 0);
        string operand = instruction.substr(firstSpace + 1, instruction.length());
        operand = trim(operand);

        // Verify if the operand is a numeric value
        if (isNumeric(operand))
        {
            literalTable.push_back({convertToDecimal(operand), -1});
        }
    }
    return errorMessages;
}
void analyzeFile(const string &filename, ofstream &logStream)
{
    // Temporary string for reading each line
    string currentLine;
    int currentLocation = 0;
    int lineNumber = 1;

    // Open the input file
    ifstream inputFile(filename);

    // Process each line in the file
    while (getline(inputFile, currentLine))
    {
        // Remove comments and trim whitespace from the line
        string instruction = currentLine.substr(0, currentLine.find(";", 0));
        instruction = trim(instruction);

        // Skip lines that are empty after trimming
        if (instruction.empty())
        {
            lineNumber++;
            continue;
        }

        // Process the instruction and log any errors
        logStream << addInstructionToTables(instruction, &currentLocation, lineNumber++);
        currentLocation++;
    }

    // Assign addresses to literals not yet placed
    for (auto &literalEntry : literalTable)
    {
        if (literalEntry.location == -1)
        {
            literalEntry.location = currentLocation++;
        }
    }

    // Close the input file after processing
    inputFile.close();
}

tuple<string, string, string> generateMachineCode(const string &instruction, int *loc_ptr, int line)
{
    // Program Counter
    int loc = *loc_ptr;

    // Hex Code for the Program Counter
    string encoding = intToHex(loc) + " ";

    // To store warnings, errors, and machine code
    string warningMessages = "";
    string errorMessages = "";
    string machineCode = "";

    // Check if the instruction contains a label
    if (instruction.find(':') != string::npos)
    {
        int colonIndex = instruction.find(":");

        // Process the instruction after the label
        if (colonIndex != instruction.length() - 1)
        {
            string remainder = instruction.substr(colonIndex + 1);
            remainder = trim(remainder);

            // Recursively process the rest of the instruction
            tie(warningMessages, errorMessages, machineCode) = generateMachineCode(remainder, loc_ptr, line);

            // Add the relevant part of the encoding from the previous instruction
            string tempEncoding = encoding;
            tempEncoding = tempEncoding.substr(9, 9); // Extract PC value and add it
            encoding += tempEncoding;
        }
        else
        {
            // If no instruction follows the label, don’t update the program counter
            encoding += "         ";
            *loc_ptr = *loc_ptr - 1; // Decrement location
        }

        encoding += instruction + "\n";
    }
    else
    {
        // Instruction does not contain a label, so process the operands
        int spaceIndex = instruction.find(" ");
        string operation = instruction.substr(0, spaceIndex);
        string operand = instruction.substr(spaceIndex + 1);

        operand = trim(operand);
        operation = trim(operation);

        // Check if the mnemonic is valid
        if (mot[operation] == "")
        {
            errorMessages += "ERROR: Undefined mnemonic at line " + to_string(line) + "\n";
            cout << "ERROR: Undefined mnemonic at line " << line << endl;
        }
        // Handle no-operand instructions
        else if (operation == "add" || operation == "sub" || operation == "shl" ||
                 operation == "shr" || operation == "a2sp" || operation == "sp2a" ||
                 operation == "return" || operation == "HALT")
        {
            encoding += "000000" + mot[operation] + " ";
            machineCode += "000000" + mot[operation] + " ";

            if (operation.length() != instruction.length())
            {
                errorMessages += "ERROR: Operand not expected at line " + to_string(line) + "\n";
                cout << "ERROR: Operand not expected at line " << line << endl;
            }
        }
        // Handle numeral operands directly
        else if (isNumeric(operand))
        {
            string hexOperand = intToHex(convertToDecimal(operand));
            encoding += hexOperand.substr(hexOperand.length() - 6) + mot[operation] + " ";
            machineCode += hexOperand.substr(hexOperand.length() - 6) + mot[operation] + " ";
        }
        else
        {
            // Handle variable operands by checking the symbol table
            bool symbolFound = false;
            for (const auto &sym : symbolTable)
            {
                if (sym.identifier == operand)
                {
                    symbolFound = true;
                    string hexOperand;

                    if (sym.isInitialized)
                    {
                        hexOperand = intToHex(sym.initialValue);
                    }
                    else if (operation == "call" || operation == "brz" || operation == "brlz" || operation == "br")
                    {
                        hexOperand = intToHex(sym.memoryAddress - loc - 1);
                    }
                    else
                    {
                        hexOperand = intToHex(sym.memoryAddress);
                    }

                    encoding += hexOperand.substr(hexOperand.length() - 6) + mot[operation] + " ";
                    machineCode += hexOperand.substr(hexOperand.length() - 6) + mot[operation] + " ";
                    break;
                }
            }

            if (!symbolFound)
            {
                errorMessages += "ERROR: Unknown symbol as operand at line " + to_string(line) + "\n";
                cout << "ERROR: Unknown symbol as operand at line " << line << endl;
            }
            else if (operation.length() == instruction.length())
            {
                errorMessages += "ERROR: Operand expected at line " + to_string(line) + "\n";
                cout << "ERROR: Operand expected at line " << line << endl;
            }
        }

        encoding += instruction + "\n";
    }

    return make_tuple(encoding, errorMessages, machineCode);
}

void generateExecutable(string inputFile, ofstream &listingFile, ofstream &logFile, ofstream &objectFile)
{
    string line;
    int loc = 0;       // Program Counter
    int lineCount = 1; // Line counter
    int linenumber = 0;
    // Open the input file for reading
    ifstream input(inputFile);

    // Process each line of the input file
    while (getline(input, line))
    {
        // Trim comments and extra spaces from the line
        string instruction = line.substr(0, line.find(";", 0));
        instruction = trim(instruction);

        // Skip empty lines
        if (instruction.empty())
        {
            lineCount++;
            continue;
        }

        // Process the instruction and get the encoded values
        string encoding, errors, machineCode;
        tie(encoding, errors, machineCode) = generateMachineCode(instruction, &loc, lineCount++);

        // Write the encoding and errors to the appropriate files
        listingFile << encoding;
        logFile << errors;

        // If machine code exists, write it to the object file in binary format
        if (!machineCode.empty())
        {
            uint32_t temp = stoul("0x" + trim(machineCode), nullptr, 16);
            objectFile.write(reinterpret_cast<char *>(&temp), sizeof(temp));
        }

        loc++; // Increment program counter after processing each instruction
    }

    // Close the input file after reading
    input.close();
}

int main(int argc, char *argv[])
{
    // Ensure the correct number of arguments are passed
    if (argc < 2)
    {
        std::cerr << "ERROR: Input file not specified!" << std::endl;
        return 1;
    }

    // Get the input file name from the command line arguments
    string inFile = argv[1];

    // Derive output file names from the input file (with appropriate extensions)
    string outFile = inFile.substr(0, inFile.find(".")) + ".L";
    string logFile = inFile.substr(0, inFile.find(".")) + ".log";
    string objFile = inFile.substr(0, inFile.find(".")) + ".o";

    // Open output files for writing
    ofstream outFileStream(outFile);
    ofstream logFileStream(logFile);
    ofstream objFileStream(objFile, ios::out | ios::binary);

    // Check if output files are successfully opened
    if (!outFileStream.is_open())
    {
        std::cerr << "ERROR: Unable to open output listing file: " << outFile << std::endl;
        return 1;
    }
    if (!logFileStream.is_open())
    {
        std::cerr << "ERROR: Unable to open log file: " << logFile << std::endl;
        return 1;
    }
    if (!objFileStream.is_open())
    {
        std::cerr << "ERROR: Unable to open object file: " << objFile << std::endl;
        return 1;
    }

    // Pass-1: Analyze the assembly code and log errors
    analyzeFile(inFile, logFileStream);

    // Pass-2: Synthesize machine code and generate object file
    generateExecutable(inFile, outFileStream, logFileStream, objFileStream);
    int filestream;
    // Close all output files after processing
    outFileStream.close();
    logFileStream.close();
    objFileStream.close();

    std::cout << "Assembly process completed successfully!" << std::endl;

    return 0;
}